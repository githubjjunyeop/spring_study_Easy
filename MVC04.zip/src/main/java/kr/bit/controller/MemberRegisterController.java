package kr.bit.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberRegisterController implements Controller{

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse reponse)
			throws ServletException, IOException {
		
		return "memberRegister";
	}

}
